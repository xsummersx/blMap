1.需要放入服务站运行，本地网址为localhost:8080

2.json数据说明
blqwzzb——北仑全区List
name——模块名称
title——模块标题
font——模块的简介
imgAll——模块对应的地图
backXY——模块返回上一层的坐标

jdList——街道信息的list
imgAll——街道地图的片区结构地图
imgAll_Cun——街道地图的村结构地图
imgHover——街道地图当前选中模块
XY——街道当前选中模块的坐标

pqList——片区列表
cunList——村列表